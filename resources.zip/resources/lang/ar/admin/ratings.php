<?php 
return [
    "list" => [
        "service" => "الخدمه",
        "payer" => "البائع",
        "client" => "العميل",
        "rate" => "التقييم",
        "feedback" => "التعليق",
        "edit" => "تعديل",
        "delete" => "حذف",
    ]
];