<?php 
return [
    "label" => "اعدادات الموقع",
    "form"  => [
        "site_title" => "عنوان الموقع",
        "site_fees"  => "رسوم الموقع",
        "site_logo"  => "شعار الموقع",
        "privacy_policy" => "سياسه الخصوصيه",
        "terms_and_conditions" => "الشروط والاحكام",
        "save"       => "حفظ"
    ]
];