<?php 
    return [
        "menu" => [
            "payers" => "البائعين",
            "categories" => "التصنيفات",
            "services" => "الخدمات",
            "user_services" => "خدمات المستخدمين",
            "clients" => "الاعضاء",
            "orders" => "الطلبات",
            "incomings" => "الواردات",
            "outgoings" => "الصادرات",
            "ratings" => "التقييم",
            "settings" => "الاعدادات",
            "admins" => "الاداره",
            "logout" => "تسجيل الخروج",
        ]
    ];