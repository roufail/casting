<?php 
return [
   "list" => [
        "incomings"      => "الواردات",
        "service"        => "الخدمه",
        "payer"          => "البائع",
        "client"         => "العميل",
        "price"          => "السعر",
        "fees"           => "الرسوم",
        "total"          => "الاجمالي",
        "status"         => "الحاله",
        "edit"           => "تعديل",
        "send"           => "ارسال",
    ]
];