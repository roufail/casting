<?php 
return [
   "list" => [
        "orders" => "الطلبات",
        "service" => "الخدمه",
        "payer" => "البائع",
        "client" => "العميل",
        "price" => "السعر",
        "status" => "الحاله",
        "chat"   => "المحادثه"
    ]
];