<?php 
return [
   "list" => [
        "incomings"      => "الواردات",
        "service"        => "الخدمه",
        "payer"          => "البائع",
        "client"         => "العميل",
        "price"          => "السعر",
        "status"         => "الحاله",
        "received"       => "تم الاستلام",
        "delivered"      => "تم التسليم",
        "deliver_date"   => "تاريخ التسليم"
    ]
];